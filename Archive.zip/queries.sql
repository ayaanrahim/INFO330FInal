-- What player shot the most free throws in the 2016 NBA Season?
select playerName from boxscore where game_id in (select game_id from games where seasonStartYear = 2018) order by FTA desc limit 1;

-- What players shot perfectly from three off a minimum of 3 point shots attempted in a game in the 2000 season?
select playerName, (CAST ("3P"AS REAL)/CAST("3PA" AS REAL) )AS accuracy, "3PA" from boxscore where game_id in (select game_id from games where seasonStartYear = 2000) AND "3PA" > 3 AND accuracy = 1;

-- Who are the heaviest and lightest players recorded since the 1996 season?
select playerName from player_info where Wt != "" order by Wt desc limit 1;
select playerName from player_info where Wt != "" order by Wt asc limit 1;

-- What player scored the most points off the bench since 1996?
SELECT playerName, CAST(PTS AS INT) as points from boxscore WHERE isStarter = 0 ORDER BY "points" DESC LIMIT 1;

-- What 5 teams had the highest attendance in game in the 1997 season?
SELECT homeTeam AS team,  MAX(attendance) AS max_attendance FROM games
WHERE seasonStartYear = 1997
GROUP BY
    homeTeam
ORDER BY
    max_attendance DESC LIMIT 5;

-- What 5 teams won the most games at home in the 2019 season?
WITH home_game_winners AS (
    SELECT
        homeTeam AS winner
    FROM
        games
    WHERE
        seasonStartYear = 2019 AND pointsHome > pointsAway
)
SELECT
    winner, COUNT(*) AS wins
FROM home_game_winners
GROUP BY winner
ORDER BY wins DESC
LIMIT 5;

-- Which player had the most assists in a game ever?
select playerName from boxscore order by cast(AST as int) desc limit 1;

-- Of all current players in each position, who should I draft on my fantasy team if I want to maximize points per game (guard)?
SELECT
    playerName,
    AVG((CAST("3P" AS REAL) * 3 + CAST(FG AS REAL) * 2 + CAST(FT AS REAL)
    + CAST(TRB AS REAL) * 1.2 + CAST(AST AS REAL) * 1.5 + CAST(BLK AS REAL) * 2
    + CAST(STL AS REAL) * 2 - CAST(TOV AS REAL))) AS AvgFP
FROM
    boxscore
WHERE
    game_id IN (SELECT game_id FROM games WHERE seasonStartYear = 2019) AND
    playerName IN (SELECT playerName FROM player_info WHERE Pos = 'G')
GROUP BY
    playerName
    ORDER BY "AvgFP" DESC
    LIMIT 1;

-- Of all current players in each position, who should I draft on my fantasy team if I want to maximize points per game (forward)?
SELECT
    playerName,
    AVG((CAST("3P" AS REAL) * 3 + CAST(FG AS REAL) * 2 + CAST(FT AS REAL)
    + CAST(TRB AS REAL) * 1.2 + CAST(AST AS REAL) * 1.5 + CAST(BLK AS REAL) * 2
    + CAST(STL AS REAL) * 2 - CAST(TOV AS REAL))) AS AvgFP
FROM
    boxscore
WHERE
    game_id IN (SELECT game_id FROM games WHERE seasonStartYear = 2019) AND
    playerName IN (SELECT playerName FROM player_info WHERE Pos = 'F')
GROUP BY
    playerName
    ORDER BY "AvgFP" DESC
    LIMIT 1;
-- Of all current players in each position, who should I draft on my fantasy team if I want to maximize points per game (center)?
SELECT
    playerName,
    AVG((CAST("3P" AS REAL) * 3 + CAST(FG AS REAL) * 2 + CAST(FT AS REAL)
    + CAST(TRB AS REAL) * 1.2 + CAST(AST AS REAL) * 1.5 + CAST(BLK AS REAL) * 2
    + CAST(STL AS REAL) * 2 - CAST(TOV AS REAL))) AS AvgFP
FROM
    boxscore
WHERE
    game_id IN (SELECT game_id FROM games WHERE seasonStartYear = 2019) AND
    playerName IN (SELECT playerName FROM player_info WHERE Pos = 'C')
GROUP BY
    playerName
    ORDER BY "AvgFP" DESC
    LIMIT 1;
