.mode csv
.import boxscore.csv imported_box_score
.import games.csv imported_games
.import player_info.csv imported_player_info
create table games (seasonStartYear int, awayTeam text, pointsAway int, homeTeam text, pointsHome int, attendance int, datetime text, isRegular int, game_id integer primary key);
insert into games (seasonStartYear, awayTeam, pointsAway, homeTeam, pointsHome, attendance, datetime, isRegular, game_id) select seasonStartYear, awayTeam, pointsAway, homeTeam, pointsHome, attendance, datetime, isRegular, game_id from imported_games;
drop table imported_games;
create table split_college as select Colleges, trim(value) split_value from imported_player_info, json_each('["' || replace(Colleges, ',', '","') || '"]') where split_value <> '';
delete from split_college where rowid not in (select min(rowid) from split_college group by Colleges, split_value);
create table player_info_temp as select imported_player_info.*, split_college.split_value from imported_player_info left join split_college on imported_player_info.Colleges = split_college.Colleges;
create table player_info_temp2 as select playerName, [From], [To], Pos, Ht, Wt, birthDate, player_id, split_value from player_info_temp;
drop table player_info_temp;
drop table split_college;
create table college (college_id integer primary key autoincrement, college_name text);
insert into college (college_name) select distinct split_value from player_info_temp2;
create table player_college as select distinct player_id, college_id from player_info_temp2 left join college on player_info_temp2.split_value = college.college_name;
create table player_info as select distinct player_id, playerName, [From], [To], Pos, Ht, Wt, birthDate from player_info_temp2;
drop table player_info_temp2;
create table player_games2 (combo integer primary key autoincrement, game_id text, playerName text);
insert into player_games2 (game_id, playerName) select game_id, playerName from games cross join player_info;
alter table player_games2 rename to player_game;
create table boxscore as select imported_box_score.*, player_game.combo from imported_box_score join player_game on imported_box_score.playerName = player_game.playerName and imported_box_score.game_id = player_game.game_id;
drop table imported_box_score;
drop table imported_player_info;
delete from boxscore where MP = "Player Suspended";
delete from boxscore where MP = "Did Not Play";
delete from boxscore where MP = "Did Not Dress";
delete from boxscore where MP = "Not With Team";
